#!/bin/bash

# Get current timestamp
timestamp=$(date '+%Y-%m-%d %H:%M:%S')

# Get uptime info
uptime_info=$(uptime -p)

# Get CPU usage (1-minute, 5-minute, and 15-minute average)
cpu_load=$(top -bn1 | grep "load average" | awk '{print $10 $11 $12}')

# Get RAM usage
mem_usage=$(free -m | awk 'NR==2{printf "Used: %sMB / Total: %sMB", $3, $2}')

# Get disk usage
disk_usage=$(df -h / | awk 'NR==2{printf "Used: %s / Total: %s", $3, $2}')

# Save to file in web-accessible folder
echo "[$timestamp] Uptime: $uptime_info | CPU Load: $cpu_load | RAM: $mem_usage | Disk: $disk_usage" >> /var/www/html/server_status.txt
