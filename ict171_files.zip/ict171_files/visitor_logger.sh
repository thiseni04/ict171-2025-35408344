#!/bin/bash

# Get current time
timestamp=$(date '+%Y-%m-%d %H:%M:%S')

# Find top 5 visiting IPs from Apache access log
top_ips=$(awk '{print $1}' /var/log/apache2/access.log | sort | uniq -c | sort -nr | head -5)

# Write to file accessible via browser
{
  echo "[$timestamp] Top 5 Visitor IPs:"
  echo "$top_ips"
  echo ""
} >> /var/www/html/visitor_log.txt
